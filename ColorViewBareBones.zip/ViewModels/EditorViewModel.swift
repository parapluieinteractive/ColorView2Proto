import SwiftUI
final class EditorViewModel: ObservableObject { @Published var red=0.5; @Published var green=0.5; @Published var blue=0.5; @Published var alpha=1.0; var color: Color { Color(red:red,green:green,blue:blue,opacity:alpha) } }
