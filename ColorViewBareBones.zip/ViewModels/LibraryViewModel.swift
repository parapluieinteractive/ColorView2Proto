import Foundation
final class LibraryViewModel: ObservableObject { @Published var colors:[SavedColor]=[] }
