import SwiftUI
struct SavedColor: Identifiable { let id=UUID(); var name=""; var red=0.5; var green=0.5; var blue=0.5; var alpha=1.0; var notes="" }
