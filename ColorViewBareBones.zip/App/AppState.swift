import Foundation
final class AppState {}
