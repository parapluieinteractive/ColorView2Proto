import SwiftUI
@main struct ColorViewApp: App { var body: some Scene { WindowGroup { RootView() } } }
