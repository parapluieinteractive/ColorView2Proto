import SwiftUI
enum ContrastEngine { static func textColor(for: Color)->Color { .white } }
