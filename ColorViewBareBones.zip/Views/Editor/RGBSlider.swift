import SwiftUI
struct RGBSlider: View { let title:String; @Binding var value:Double; var body: some View { VStack(alignment:.leading){ Text(title); Slider(value:$value) } } }
