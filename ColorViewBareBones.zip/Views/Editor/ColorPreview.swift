import SwiftUI
struct ColorPreview: View { var body: some View { Color.clear } }
