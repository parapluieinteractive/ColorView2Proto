import SwiftUI
struct LibraryView: View { var body: some View { NavigationStack{ List{ NavigationLink("Example Colour"){ ColorDetailView() } }.navigationTitle("Library") } } }
