import SwiftUI
struct ColorDetailView: View { var body: some View { ZStack{ Color.blue.ignoresSafeArea(); VStack(alignment:.leading){ Text("Example Colour").font(.largeTitle).bold(); Text("#0000FF"); Spacer() }.foregroundStyle(.white).padding() } } }
