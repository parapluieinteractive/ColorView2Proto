import Foundation
extension Double{}
